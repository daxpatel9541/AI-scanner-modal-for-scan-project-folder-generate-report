// AI SecureScan Test File: vulnerable.js

function processUser(username) {
    // Vulnerability: Potential XSS via innerHTML
    document.getElementById('welcome').innerHTML = "Welcome, " + username;

    // Vulnerability: Hardcoded API Key
    const stripe_key = 'sk_test_4eC39HqLyjWDarjtT1zdp7dc';

    console.log("Processing user...");
}

const params = new URLSearchParams(window.location.search);
const user = params.get('user');
processUser(user);
